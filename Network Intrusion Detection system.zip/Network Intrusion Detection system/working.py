import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

def predicting(selected_parameters):
    df = pd.read_csv("Preprocessed_data.csv")
    x = df[['duration', 'protocol_type', 'service', 'flag', 'land', 'wrong_fragment', 'root_shell', 'num_shells', 'num_access_files',
            'is_guest_login', 'count', 'srv_count',
            'rerror_rate', 'srv_rerror_rate', 'same_srv_rate', 'diff_srv_rate', 'srv_diff_host_rate',
            'dst_host_count', 'dst_host_srv_count', 'dst_host_same_srv_rate', 'dst_host_diff_srv_rate',
            'dst_host_same_src_port_rate', 'dst_host_srv_diff_host_rate', 'dst_host_rerror_rate',
            'dst_host_srv_rerror_rate']]
    y = df['attack']
    
    X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.25, random_state=0)
    rf = RandomForestClassifier()
    rf.fit(X_train, y_train)
        
    # Preprocess parameters
    preprocessed_parameters = preprocess_parameters(selected_parameters)
    # Convert the preprocessed parameters into a DataFrame
    input_data = pd.DataFrame(preprocessed_parameters, index=[0])[['duration', 'protocol_type', 'service', 'flag', 
                                                                   'land', 'wrong_fragment',  'root_shell', 'num_shells', 
                                                                   'num_access_files', 'is_guest_login', 'count', 
                                                                   'srv_count', 'rerror_rate', 'srv_rerror_rate', 
                                                                   'same_srv_rate', 'diff_srv_rate', 'srv_diff_host_rate', 
                                                                   'dst_host_count', 'dst_host_srv_count', 
                                                                   'dst_host_same_srv_rate', 'dst_host_diff_srv_rate', 
                                                                   'dst_host_same_src_port_rate', 
                                                                   'dst_host_srv_diff_host_rate', 'dst_host_rerror_rate', 
                                                                   'dst_host_srv_rerror_rate']]
    
    # Make predictions
    prediction = rf.predict(input_data)
    
    return prediction


# Preprocess function
def preprocess_parameters(parameters):
    # Define mappings for categorical variables
    protocol_type_mapping = {"tcp": 0, "udp": 1, "icmp": 2}
    service_mapping = {'ftp_data': 0, 'other': 1, 'private': 2, 'http': 3, 'remote_job': 4, 'name': 5,
                        'netbios_ns': 6, 'eco_i': 7, 'mtp': 8, 'telnet': 9, 'finger': 10, 'domain_u': 11,
                       'supdup': 12, 'uucp_path': 13, 'Z39_50': 14, 'smtp': 15, 'csnet_ns': 16, 'uucp': 17,
                       'netbios_dgm': 18, 'urp_i': 19, 'auth': 20, 'domain': 21, 'ftp': 22, 'bgp': 23, 'ldap': 24,
                       'ecr_i': 25, 'gopher': 26, 'vmnet': 27, 'systat': 28, 'http_443': 29, 'efs': 30, 'whois': 31,
                       'imap4': 32, 'iso_tsap': 33, 'echo': 34, 'klogin': 35, 'link': 36, 'sunrpc': 37, 'login': 38,
                       'kshell': 39, 'sql_net': 40, 'time': 41, 'hostnames': 42, 'exec': 43, 'ntp_u': 44,
                       'discard': 45, 'nntp': 46, 'courier': 47, 'ctf': 48, 'ssh': 49, 'daytime': 50, 'shell': 51,
                       'netstat': 52, 'pop_3': 53, 'nnsp': 54, 'IRC': 55, 'pop_2': 56, 'printer': 57, 'tim_i': 58,
                       'pm_dump': 59, 'red_i': 60, 'netbios_ssn': 61, 'rje': 62, 'X11': 63, 'urh_i': 64,
                       'http_8001': 65, 'aol': 66, 'http_2784': 67, 'tftp_u': 68, 'harvest': 69}
    flag_mapping = {'SF': 0, 'S0': 1, 'REJ': 2, 'RSTR': 3, 'SH': 4, 'RSTO': 5, 'S1': 6, 'RSTOS0': 7, 'S3': 8, 'S2': 9, 'OTH': 10}

    # Map categorical variables to numerical representations
    preprocessed_parameters = {
        "protocol_type": protocol_type_mapping.get(parameters.get("protocol_type", ""), 0),
        "service": service_mapping.get(parameters.get("service", ""), len(service_mapping)),
        "flag": flag_mapping.get(parameters.get("flag", ""), len(flag_mapping))
    }

    # Map numerical parameters
    numerical_params = [
        "duration", "land", "wrong_fragment", "root_shell", "num_shells", "num_access_files", "is_guest_login",
        "count", "srv_count", "rerror_rate", "srv_rerror_rate", "same_srv_rate", "diff_srv_rate",
        "srv_diff_host_rate", "dst_host_count", "dst_host_srv_count", "dst_host_same_srv_rate",
        "dst_host_diff_srv_rate", "dst_host_same_src_port_rate", "dst_host_srv_diff_host_rate",
        "dst_host_rerror_rate", "dst_host_srv_rerror_rate"
    ]
    for param_name in numerical_params:
        preprocessed_parameters[param_name] = parameters.get(param_name, 0)

    return preprocessed_parameters


def main():
    st.title('Network Intrusion Detection System')

    # Define the parameters and their options
    parameters_options = {
        "duration": None,
        "protocol_type": ["tcp", "udp", "icmp"],
        "service": ['ftp_data', 'other', 'private', 'http', 'remote_job', 'name',
                    'netbios_ns', 'eco_i', 'mtp', 'telnet', 'finger', 'domain_u',
                    'supdup', 'uucp_path', 'Z39_50', 'smtp', 'csnet_ns', 'uucp',
                    'netbios_dgm', 'urp_i', 'auth', 'domain', 'ftp', 'bgp', 'ldap',
                    'ecr_i', 'gopher', 'vmnet', 'systat', 'http_443', 'efs', 'whois',
                    'imap4', 'iso_tsap', 'echo', 'klogin', 'link', 'sunrpc', 'login',
                    'kshell', 'sql_net', 'time', 'hostnames', 'exec', 'ntp_u',
                    'discard', 'nntp', 'courier', 'ctf', 'ssh', 'daytime', 'shell',
                    'netstat', 'pop_3', 'nnsp', 'IRC', 'pop_2', 'printer', 'tim_i',
                    'pm_dump', 'red_i', 'netbios_ssn', 'rje', 'X11', 'urh_i',
                    'http_8001', 'aol', 'http_2784', 'tftp_u', 'harvest'],
        "flag": ['SF', 'S0', 'REJ', 'RSTR', 'SH', 'RSTO', 'S1', 'RSTOS0', 'S3', 'S2', 'OTH'],
        "land": [0, 1],
        "wrong_fragment": [0, 3, 1],
        "root_shell": [0, 1],
        "num_shells": [0, 1, 2],
        "num_access_files": [0, 1, 2, 3, 5, 4, 8, 6, 7, 9],
        "is_guest_login": [0, 1],
        "count": None,
        "srv_count": None,
        "rerror_rate": None,
        "srv_rerror_rate": [0, 1],
        "same_srv_rate": None,
        "diff_srv_rate": None,
        "srv_diff_host_rate": None,
        "dst_host_count": [0, 1],
        "dst_host_srv_count": [0, 1],
        "dst_host_same_srv_rate": None,
        "dst_host_diff_srv_rate": None,
        "dst_host_same_src_port_rate": None,
        "dst_host_srv_diff_host_rate": None,
        "dst_host_rerror_rate": None,
        "dst_host_srv_rerror_rate": None,
    }

    # Get the parameter values from the user
    selected_parameters = {}
    num_params = len(parameters_options)
    col1, col2 = st.columns(2)  # Split the layout into two columns

    for i, (param_name, options) in enumerate(parameters_options.items()):
        if i < num_params // 2:  # Put the first half of parameters in the left column
            with col1:
                if options is not None:
                    selected_parameters[param_name] = st.selectbox(param_name, options)
                elif param_name in ["same_srv_rate", "diff_srv_rate", "dst_host_same_srv_rate", "dst_host_diff_srv_rate",
                            "dst_host_same_src_port_rate", "dst_host_srv_diff_host_rate", "dst_host_rerror_rate",
                            "dst_host_srv_rerror_rate"]:
                    selected_parameters[param_name] = st.number_input(param_name, value=0.0, step=0.01, min_value=0.0, max_value=1.0)
                else:
                    selected_parameters[param_name] = st.number_input(param_name, value=0)
        else:  # Put the second half of parameters in the right column
            with col2:
                if options is not None:
                    selected_parameters[param_name] = st.selectbox(param_name, options)
                elif param_name in ["same_srv_rate", "diff_srv_rate", "dst_host_same_srv_rate", "dst_host_diff_srv_rate",
                            "dst_host_same_src_port_rate", "dst_host_srv_diff_host_rate", "dst_host_rerror_rate",
                            "dst_host_srv_rerror_rate"]:
                    selected_parameters[param_name] = st.number_input(param_name, value=0.0, step=0.01, min_value=0.0, max_value=1.0)
                else:
                    selected_parameters[param_name] = st.number_input(param_name, value=0)
                    
                        # Button to preprocess and submit the input
    if st.button('Preprocess and Submit'):
        # Preprocess parameters and make predictions
        prediction = predicting(selected_parameters)
        attack_mapping = {
            1: 'normal', 2: 'neptune', 3: 'warezclient', 4: 'ipsweep', 5: 'portsweep',
            6: 'teardrop', 7: 'nmap', 8: 'satan', 9: 'smurf', 10: 'pod',
            11: 'back', 12: 'guess_passwd', 13: 'ftp_write', 14: 'multihop',
            15: 'rootkit', 16: 'buffer_overflow', 17: 'imap', 18: 'warezmaster',
            19: 'phf', 20: 'land', 21: 'loadmodule', 22: 'spy', 23: 'perl'
        }

        # Convert numerical output to attack type
        predicted_attack_type = attack_mapping.get(prediction[0])

        # Display predicted attack type
        st.write('Predicted Attack Type:', predicted_attack_type)

if __name__ == '__main__':
    main()
